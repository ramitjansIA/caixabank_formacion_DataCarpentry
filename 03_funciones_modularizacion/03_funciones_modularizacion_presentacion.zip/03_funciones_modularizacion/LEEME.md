# 03 · Funciones reutilizables

28 diapositivas con ejemplos antes/después, esquemas animados y discurso del profesor en bloques `.notes`.

- Abrir presentacion.html. Flechas: avanzar. S: presentador. F: pantalla completa. O: vista general.
- Editar presentacion.qmd y ejecutar `quarto render presentacion.qmd` desde esta carpeta con Quarto instalado.
- Conservar los CSS y recursos junto al QMD. Las notas están incluidas en el archivo, pero ocultas en la vista normal.

El HTML utiliza el motor Reveal.js autocontenido del proyecto. No se ha compilado con Quarto en este entorno.

Propuesta de una hora: diseño y parámetros (15 min), efectos secundarios (10 min), tipos y validación (10 min), documentación y composición (10 min), práctica (10 min), cierre (5 min). Adaptar demostraciones al ritmo del grupo.

Ejemplos de enseñanza: las llamadas con DataFrames y el pipeline presuponen datos, bibliotecas y funciones de la guía. No son un paquete completo instalable.
